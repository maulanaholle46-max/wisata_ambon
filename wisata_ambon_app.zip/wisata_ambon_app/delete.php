
<?php
require_once __DIR__.'/config/db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$token = $_GET['token'] ?? '';

if (!$id || !csrf_token_validate($token)) {
    set_flash('danger', 'Permintaan tidak valid.');
    header('Location: index.php');
    exit;
}

$stmt = $mysqli->prepare("DELETE FROM wisata WHERE id_wisata=?");
$stmt->bind_param('i', $id);
if ($stmt->execute()) {
    set_flash('success', 'Data berhasil dihapus.');
} else {
    set_flash('danger', 'Gagal menghapus data: '.$stmt->error);
}
header('Location: index.php');
exit;
