
<?php
require_once __DIR__.'/config/db.php';

$csrf = $_POST['csrf_token'] ?? '';
if (!csrf_token_validate($csrf)) {
    set_flash('danger', 'Token tidak valid.');
    header('Location: index.php');
    exit;
}

$id = (int)($_POST['id'] ?? 0);
$nama = trim($_POST['nama_wisata'] ?? '');
$lokasi = trim($_POST['lokasi'] ?? '');
$kategori = trim($_POST['kategori'] ?? '');
$deskripsi = trim($_POST['deskripsi'] ?? '');
$tahun = trim($_POST['tahun_ditetapkan'] ?? '');

$errors = [];
if ($nama === '' || $lokasi === '' || $kategori === '' || $deskripsi === '' || $tahun === '') {
    $errors[] = 'Semua field wajib diisi.';
}
if (!preg_match('/^\d{4}$/', $tahun)) {
    $errors[] = 'Tahun harus 4 digit (YYYY).';
}
if ($errors) {
    set_flash('danger', implode(' ', $errors));
    header('Location: edit.php?id='.$id);
    exit;
}

$stmt = $mysqli->prepare("UPDATE wisata SET nama_wisata=?, lokasi=?, kategori=?, deskripsi=?, tahun_ditetapkan=? WHERE id_wisata=?");
$stmt->bind_param('ssssii', $nama, $lokasi, $kategori, $deskripsi, $tahun, $id);
if ($stmt->execute()) {
    set_flash('success', 'Data berhasil diupdate.');
    header('Location: index.php');
    exit;
} else {
    set_flash('danger', 'Gagal update data: '.$stmt->error);
    header('Location: edit.php?id='.$id);
    exit;
}
