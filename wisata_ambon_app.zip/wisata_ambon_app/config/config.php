<?php
// Konfigurasi dasar aplikasi
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'pariwisata_ambon');

// Kunci aplikasi (untuk CSRF token sederhana)
define('APP_KEY', 'ganti_dengan_string_unik_anda');

// Base URL (opsional, sesuaikan jika perlu, contoh di hosting: 'https://domainmu.com')
$BASE_URL = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
    . '://' . $_SERVER['HTTP_HOST']
    . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');

// Start session untuk flash message & CSRF
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Flash helper
function set_flash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}
function get_flash() {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

// CSRF helpers
function csrf_token_generate() {
    $token = bin2hex(random_bytes(16));
    $_SESSION['csrf_token'] = hash_hmac('sha256', $token, APP_KEY);
    $_SESSION['csrf_raw'] = $token;
    return $_SESSION['csrf_token'];
}
function csrf_token_input() {
    if (empty($_SESSION['csrf_token'])) {
        csrf_token_generate();
    }
    echo '<input type="hidden" name="csrf_token" value="'.htmlspecialchars($_SESSION['csrf_token']).'">';
}
function csrf_token_validate($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
