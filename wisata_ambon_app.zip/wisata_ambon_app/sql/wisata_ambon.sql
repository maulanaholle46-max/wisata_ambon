DROP TABLE IF EXISTS `wisata`;
CREATE TABLE `wisata` (
  `id_wisata` INT AUTO_INCREMENT PRIMARY KEY,
  `nama_wisata` VARCHAR(100) NOT NULL,
  `lokasi` VARCHAR(100) NOT NULL,
  `kategori` VARCHAR(50) NOT NULL,
  `deskripsi` TEXT NOT NULL,
  `tahun_ditetapkan` YEAR NOT NULL,
  `gambar` VARCHAR(255) DEFAULT NULL,
  `latitude` DECIMAL(10,8) DEFAULT NULL,
  `longitude` DECIMAL(11,8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Data contoh
INSERT INTO `wisata` 
(`nama_wisata`, `lokasi`, `kategori`, `deskripsi`, `tahun_ditetapkan`, `gambar`, `latitude`, `longitude`) VALUES
('Pantai Natsepa', 'Suli, Salahutu', 'Pantai', 'Pantai pasir putih dengan rujak khas Ambon.', 1998, 'natsepa.jpg', -3.626389, 128.345833),
('Benteng Victoria', 'Kota Ambon', 'Budaya', 'Situs sejarah peninggalan kolonial.', 2005, 'victoria.jpg', -3.697778, 128.180000),
('Gunung Salahutu', 'Pulau Ambon', 'Gunung', 'Destinasi pendakian dengan panorama Teluk Ambon.', 2010, 'salahutu.jpg', -3.566667, 128.316667);
