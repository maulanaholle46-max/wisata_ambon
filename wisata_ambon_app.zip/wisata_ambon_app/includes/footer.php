
</div> <!-- /container -->
<footer class="border-top py-4 mt-5">
  <div class="container small text-muted">
    <div class="d-flex justify-content-between">
      <span>© <?= date('Y') ?> Wisata Ambon</span>
      <span>UAS PBD - PHP Native + MySQL + DataTables</span>
    </div>
  </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- jQuery + DataTables -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>
