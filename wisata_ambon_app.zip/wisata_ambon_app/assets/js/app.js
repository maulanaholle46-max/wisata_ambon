
document.addEventListener('DOMContentLoaded', function () {
  const table = document.getElementById('datatable');
  if (table) {
    new DataTable(table, {
      responsive: true
    });
  }
});
