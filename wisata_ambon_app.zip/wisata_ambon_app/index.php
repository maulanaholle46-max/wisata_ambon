
<?php
require_once __DIR__.'/config/db.php';
require_once __DIR__.'/includes/header.php';

// Ambil semua data wisata
$sql = "SELECT id_wisata, nama_wisata, lokasi, kategori, deskripsi, tahun_ditetapkan FROM wisata ORDER BY id_wisata DESC";
$result = $mysqli->query($sql);
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="mb-0">Daftar Destinasi Wisata</h3>
  <a href="create.php" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Tambah</a>
</div>

<div class="card">
  <div class="card-body">
    <div class="table-responsive">
      <table id="datatable" class="table table-striped table-bordered align-middle">
        <thead class="table-light">
          <tr>
            <th>ID</th>
            <th>Nama Wisata</th>
            <th>Lokasi</th>
            <th>Kategori</th>
            <th>Deskripsi</th>
            <th>Tahun</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
          <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?= (int)$row['id_wisata'] ?></td>
              <td><?= htmlspecialchars($row['nama_wisata']) ?></td>
              <td><?= htmlspecialchars($row['lokasi']) ?></td>
              <td><span class="badge bg-info text-dark"><?= htmlspecialchars($row['kategori']) ?></span></td>
              <td><?= nl2br(htmlspecialchars($row['deskripsi'])) ?></td>
              <td><?= htmlspecialchars($row['tahun_ditetapkan']) ?></td>
              <td class="text-nowrap">
                <a class="btn btn-sm btn-warning" href="edit.php?id=<?= (int)$row['id_wisata'] ?>">Edit</a>
                <a class="btn btn-sm btn-danger" href="delete.php?id=<?= (int)$row['id_wisata'] ?>&token=<?= urlencode($_SESSION['csrf_token'] ?? csrf_token_generate()) ?>" onclick="return confirm('Yakin hapus data ini?')">Hapus</a>
              </td>
            </tr>
          <?php endwhile; ?>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__.'/includes/footer.php'; ?>
