
<?php
require_once __DIR__.'/config/db.php';
require_once __DIR__.'/includes/header.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $mysqli->prepare("SELECT id_wisata, nama_wisata, lokasi, kategori, deskripsi, tahun_ditetapkan FROM wisata WHERE id_wisata=?");
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$data = $res->fetch_assoc();
if (!$data) {
    set_flash('danger', 'Data tidak ditemukan.');
    header('Location: index.php');
    exit;
}
csrf_token_generate();
?>
<div class="row">
  <div class="col-lg-8 mx-auto">
    <div class="card">
      <div class="card-header bg-white">
        <h5 class="mb-0">Edit Destinasi Wisata</h5>
      </div>
      <div class="card-body">
        <form action="update.php" method="post" novalidate>
          <?php csrf_token_input(); ?>
          <input type="hidden" name="id" value="<?= (int)$data['id_wisata'] ?>">
          <div class="mb-3">
            <label class="form-label">Nama Wisata</label>
            <input type="text" name="nama_wisata" value="<?= htmlspecialchars($data['nama_wisata']) ?>" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Lokasi</label>
            <input type="text" name="lokasi" value="<?= htmlspecialchars($data['lokasi']) ?>" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Kategori</label>
            <select name="kategori" class="form-select" required>
              <?php
                $opts = ['Pantai','Gunung','Budaya','Kuliner','Taman','Lainnya'];
                foreach ($opts as $o) {
                  $sel = ($o === $data['kategori']) ? 'selected' : '';
                  echo "<option $sel>".htmlspecialchars($o)."</option>";
                }
              ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Deskripsi</label>
            <textarea name="deskripsi" class="form-control" rows="4" required><?= htmlspecialchars($data['deskripsi']) ?></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label">Tahun Ditetapkan</label>
            <input type="number" name="tahun_ditetapkan" value="<?= htmlspecialchars($data['tahun_ditetapkan']) ?>" class="form-control" min="1900" max="2100" required>
          </div>
          <div class="d-flex gap-2">
            <button class="btn btn-primary" type="submit">Update</button>
            <a class="btn btn-secondary" href="index.php">Batal</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__.'/includes/footer.php'; ?>
