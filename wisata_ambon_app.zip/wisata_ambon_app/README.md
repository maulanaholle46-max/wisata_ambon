
# Aplikasi Manajemen Destinasi Wisata Ambon (PHP Native + MySQL)

Aplikasi ini dibuat untuk memenuhi **Kuis 2 & UAS Pemrograman Basis Data** dengan studi kasus Dinas Pariwisata Kota Ambon.

## Fitur
- CRUD (Create, Read, Update, Delete) data destinasi wisata
- Tabel dinamis menggunakan **DataTables** (search, sort, pagination)
- Validasi input sisi server (wajib isi, format tahun)
- Pesan umpan balik (flash message) sederhana
- Prepared Statement (aman dari SQL Injection)
- Struktur folder rapi + file SQL export
- Dokumentasi cara menjalankan

## Persyaratan
- PHP 7.4+ atau 8.x
- MySQL/MariaDB
- Web server lokal (XAMPP/Laragon) atau hosting cPanel

## Cara Menjalankan (Lokal)
1. Buat database dan tabel:
   - Buka **phpMyAdmin**, buat database bernama `pariwisata_ambon`.
   - Import file: `sql/wisata_ambon.sql`.
2. Salin folder `wisata_ambon_app` ke `htdocs/` (XAMPP) atau `www/` (Laragon).
3. Sesuaikan kredensial DB pada `config/config.php` jika perlu.
4. Akses di browser: `http://localhost/wisata_ambon_app/`.
5. Coba tambah data, edit, hapus, dan uji fitur DataTables.

## Catatan Keamanan
- Hapus `?del=` di URL secara manual tidak akan menghapus data tanpa token (CSRF token digunakan).
- Pastikan `display_errors` dimatikan di produksi.
- Ganti `APP_KEY` di `config/config.php` untuk hashing token yang lebih unik.

## Struktur Folder
```
wisata_ambon_app/
├─ index.php            # daftar + DataTables
├─ create.php           # form tambah
├─ edit.php             # form edit
├─ store.php            # proses simpan
├─ update.php           # proses update
├─ delete.php           # proses hapus (GET terproteksi token)
├─ config/
│  ├─ config.php        # konstanta & util
│  └─ db.php            # koneksi mysqli
├─ includes/
│  ├─ header.php        # HTML head + navbar + CDN
│  └─ footer.php        # penutup body/html + script
├─ assets/
│  ├─ css/custom.css
│  └─ js/app.js
├─ sql/wisata_ambon.sql # skema + data contoh
└─ docs/                # (opsional) dokumentasi tambahan
```

## Hosting
- Upload seluruh folder ke hosting (public_html/).
- Buat database via cPanel, import `sql/wisata_ambon.sql`.
- Ubah `config/config.php` sesuai kredensial hosting.

## Lisensi
Bebas digunakan untuk pembelajaran.
